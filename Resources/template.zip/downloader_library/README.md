Google Downloader Library

This library contains modifications to make it compatible with
Android Studio. Testing was done with the gradle-experimental
0.6.0-alpha5 plugin, and this library may not be compatible
with other versions of the gradle plugin.

You can import this module for inclusion in your Android Studio
projects that need to use the Google Downloader Library for
downloading expansion files.

See Also: Google Play Licensing Library at
  <https://github.com/monkey0506/google_play_licensing_library>