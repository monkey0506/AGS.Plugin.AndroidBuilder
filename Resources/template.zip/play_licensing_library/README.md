Google Play Licensing Library

This library contains modifications to make it compatible with
Android Studio. Testing was done with the gradle-experimental
0.6.0-alpha5 plugin, and this library may not be compatible
with other versions of the gradle plugin.

You can import this module for inclusion in your Android Studio
projects that need to use the Google Play Licensing services.