package com.bigbluecup.android;

import android.app.Activity;
import android.os.Bundle;

public class CreditsActivity extends Activity
{
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);	
		setContentView(R.layout.credits);
	}
	
}
